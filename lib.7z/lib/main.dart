import 'package:flutter/material.dart';

import 'package:hrm_attendance_application_test/screen/splash.dart';

void main() {
  runApp(const SplashScreen());
}
